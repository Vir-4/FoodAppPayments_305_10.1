package com.example.foodrescue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.util.UniversalTimeScale;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.foodrescue.FoodItem;
import com.example.foodrescue.User;
import com.example.foodrescue.Util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class DatabaseHelper extends SQLiteOpenHelper {

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Util.CREATE_USER_TABLE);
        db.execSQL(Util.CREATE_FOOD_TABLE);
    }
    public DatabaseHelper(Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VER);
    }

    @Override


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVe, int newVe) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS";

        db.execSQL(DROP_USER_TABLE, new String[] {Util.USER_TABLE_NAME, Util.FOOD_TABLE_NAME});
        onCreate(db);
    }

    public long createUser(User user){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Util.USERNAME, user.getUsername());
        values.put(Util.NAME, user.getName());
        values.put(Util.PHONE, user.getPhone());
        values.put(Util.ADDRESS, user.getAddress());
        values.put(Util.PASSWORD, user.getPassword());

        long result = db.insert(Util.USER_TABLE_NAME, null, values);

        return result;
    }

    public long createFoodItem(User user, FoodItem foodItem){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Util.FOOD_LOCATION, foodItem.getLocation());
        values.put(Util.FOOD_QUANTITY, foodItem.getQuantity());
        values.put(Util.FOOD_IMAGE, foodItem.getImageRes());
        values.put(Util.USERNAME, user.getUsername());

        values.put(Util.FOOD_TITLE, foodItem.getTitle());
        values.put(Util.FOOD_DESCR, foodItem.getDescription());
        values.put(Util.FOOD_DATE, foodItem.getPickupDate());
        values.put(Util.FOOD_PICKUP foodItem.getPickupTime());

        long result = db.insert(Util.FOOD_TABLE_NAME, null, values);

        return  result;
    }

    public User getUser(String username){

        SQLiteDatabase db = this.getReadableDatabase();
        String FETCH_USER = "SELECT * FROM " + Util.USER_TABLE_NAME +
                " WHERE " + Util.USERNAME + " = \"" + username + "\"";

        Log.e(String.valueOf(LOG), FETCH_USER);

        Cursor c = db.rawQuery(FETCH_USER, null);

        if (c.moveToFirst()){
            User user = new User();

            user.setPhone(c.getString(c.getColumnIndex(Util.PHONE)));
            user.setAddress(c.getString(c.getColumnIndex(Util.ADDRESS)));
            user.setPassword(c.getString(c.getColumnIndex(Util.PASSWORD)));
            user.setUsername(c.getString(c.getColumnIndex(Util.USERNAME)));
            user.setName(c.getString(c.getColumnIndex(Util.NAME)));


            return user;
        }
    }
    public boolean login(String username, String password){

        SQLiteDatabase db = getReadableDatabase();

        User user = getUser(username);

        if (user.getPassword().equals(password)){
            return true;
        }

        else{
            return false;
        }
    }

    public FoodItem getFoodItem(Integer foodID){

        SQLiteDatabase db = getWritableDatabase();

        String FETCH_FOOD_ITEM = "SELECT * FROM " + Util.FOOD_TABLE_NAME + " WHERE " + Util.FOOD_ID + " = \"" + foodID + "\"";

        Cursor c = db.rawQuery(FETCH_FOOD_ITEM, null);

        if(c!=null) c.moveToFirst();

        //Creating FoodItem object from cursor
        FoodItem foodItem = new FoodItem();
        foodItem.setFoodID(c.getInt(c.getColumnIndex(Util.FOOD_ID)));
        foodItem.setTitle(c.getString(c.getColumnIndex(Util.FOOD_TITLE)));
        foodItem.setDescription(c.getString(c.getColumnIndex(Util.FOOD_DESCRIPTION)));

        return foodItem;
    }

    public List<FoodItem> getAllFoodItems(){

        SQLiteDatabase db = getWritableDatabase();

        String FETCH_ALL_FOOD = "SELECT * FROM " + Util.FOOD_TABLE_NAME;

        Cursor c = db.rawQuery(FETCH_ALL_FOOD, null);

        final int dateIndex = c.getColumnIndex(Util.FOOD_DATE);
        final int timeIndex = c.getColumnIndex(Util.FOOD_PICKUP_TIME);
        final int quantityIndex = c.getColumnIndex(Util.FOOD_QUANTITY);
        final int locationIndex = c.getColumnIndex(Util.FOOD_LOCATION);
        final int imageIndex = c.getColumnIndex(Util.FOOD_IMAGE_RES);


        final int idIndex = c.getColumnIndex(Util.FOOD_ID);
        final int titleIndex = c.getColumnIndex(Util.FOOD_TITLE);
        final int descIndex = c.getColumnIndex(Util.FOOD_DESCRIPTION);


        try {
            if (!c.moveToFirst()) {
                return new ArrayList<>();
            }

            final List<FoodItem> foodItemList = new ArrayList<>();

            do {

                final String date = c.getString(dateIndex);
                final String quantity = c.getString(quantityIndex);
                final String time = c.getString(timeIndex);
                final String location = c.getString(locationIndex);

                byte[] bitmapData = c.getBlob(imageIndex);
                final Bitmap imageRes = BitmapFactory.decodeByteArray(bitmapData, 0, bitmapData.length);

                foodItemList.add(new FoodItem(title, description, date, time, location, quantity, imageRes));

            } while (c.moveToNext());

            return foodItemList;

        } finally {
            c.close();
            db.close();
        }
    }


}