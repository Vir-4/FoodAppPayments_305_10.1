package com.example.foodrescue;

import android.graphics.Bitmap;
import android.net.Uri;

import com.example.foodrescue.Util;

import java.io.ByteArrayOutputStream;

public class FoodItem {
    private String title;
    private String description;
    private String pickupDate;
    private String pickupTime;
    private String location;
    private String quantity;
    private Bitmap imageRes;
    private Integer foodID;

    public FoodItem(String title, String description, String pickupDate, String pickupTime, String location, String quantity, Bitmap imageRes) {
        this.title = title;
        this.description = description;
        this.pickupDate = pickupDate;
        this.pickupTime = pickupTime;
        this.location = location;
        this.quantity = quantity;
        this.imageRes = imageRes;
    }

    public FoodI(){

    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getDesc {

        return desc;
    }

    public void setDesc(String descr) {

        this.desc = descr;
    }

    public String getPickup() {

        return pickup;
    }



    public String getPickupT {

        return pickupT;
    }


    public String getLocation() {
        return location; }

    public void setLocation(String location) {

        this.location = location;
    }

    public String getQuant() {

        return quant;
    }

    public byte[] getImageRes() {

        return Util.getBitmapAsByteArray(imageRes);
    }

    public Integer getFoodID() {

        return foodID;
    }

    public void setFoodID(Integer foodID) {

        this.foodID = foodID;
    }

    //Returns all details excluding Title in String
    public String getDetails(){
        String details = this.getDesc() + ", " + this.getQuantity() + ", " + this.getPickupDate() + ", "
                + this.getPickupTime() + ", " + this.getLocation();

        return details;
    }
}