package com.example.foodrescue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.foodrescue.DatabaseHelper;

public class ListActivity extends AppCompatActivity {

    String username; DatabaseHelper db; RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        .onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        ;
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.myListRecyclerView);

        setRecyclerView();
    }

}