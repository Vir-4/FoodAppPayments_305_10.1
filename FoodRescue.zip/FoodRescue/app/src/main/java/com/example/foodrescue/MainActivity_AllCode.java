package com.example.foodrescue;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class AddFoodActivity extends AppCompatActivity {

    private static final String TAG = "image";

    String date; Button saveButton, addDateButton;
    ImageButton addImageButton; EditText titleEditText, descEditText, timeEditText,

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        titleEditText = findViewById(R.id.titleEditText);
        descEditText = findViewById(R.id.descEditText);
        saveButton = findViewById(R.id.saveButton);
        addDateButton = findViewById(R.id.addDateButton);
        addImageButton = findViewById(R.id.addImageButton);
        db = new DatabaseHelper(this);

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED){

                    requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST);
                }

                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }

        });

        addDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent calendarIntent = new Intent(AddFoodActivity.this, CalendarActivity.class);
                startActivityForResult(calendarIntent, 1);
            }
        });

        @Override
        protected void onActivityResult(int reqCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(reqCode, resultCode, data);

            //Getting the date result from CalendarActivity
            switch (reqCode) {

                //Handle the return of the selected food image
                case RESULT_LOAD_IMAGE:
                    if (resultCode == RESULT_OK) {

                        try {

                        }
                        Log.d(TAG, "onActivityResult: " + data.getData().getPath());

                        imageRes = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    }

                    catch (Exception e) {
                    e.printStackTrace();
                }


            }
            case RESULT_CALENDAR:
                date = data.getStringExtra("date");

                Toast.makeText(AddFoodActivity.this, "Chosen date is " + date, Toast.LENGTH_LONG).show();
                break;

        }

    }
}
    mport android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.icu.util.UniversalTimeScale;
        import android.net.Uri;
        import android.util.Log;

        import androidx.annotation.NonNull;
        import androidx.annotation.Nullable;

        import com.example.foodrescue.FoodItem;
        import com.example.foodrescue.User;
        import com.example.foodrescue.Util;

        import java.util.ArrayList;
        import java.util.Collection;
        import java.util.Iterator;
        import java.util.List;
        import java.util.ListIterator;

        import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class DatabaseHelper extends SQLiteOpenHelper {

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Util.CREATE_USER_TABLE);
        db.execSQL(Util.CREATE_FOOD_TABLE);
    }
    public DatabaseHelper(Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VER);
    }

    @Override


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVe, int newVe) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS";

        db.execSQL(DROP_USER_TABLE, new String[] {Util.USER_TABLE_NAME, Util.FOOD_TABLE_NAME});
        onCreate(db);
    }

    public long createUser(User user){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Util.USERNAME, user.getUsername());
        values.put(Util.NAME, user.getName());
        values.put(Util.PHONE, user.getPhone());
        values.put(Util.ADDRESS, user.getAddress());
        values.put(Util.PASSWORD, user.getPassword());

        long result = db.insert(Util.USER_TABLE_NAME, null, values);

        return result;
    }

    public long createFoodItem(User user, FoodItem foodItem){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Util.FOOD_LOCATION, foodItem.getLocation());
        values.put(Util.FOOD_QUANTITY, foodItem.getQuantity());
        values.put(Util.FOOD_IMAGE, foodItem.getImageRes());
        values.put(Util.USERNAME, user.getUsername());

        values.put(Util.FOOD_TITLE, foodItem.getTitle());
        values.put(Util.FOOD_DESCR, foodItem.getDescription());
        values.put(Util.FOOD_DATE, foodItem.getPickupDate());
        values.put(Util.FOOD_PICKUP foodItem.getPickupTime());

        long result = db.insert(Util.FOOD_TABLE_NAME, null, values);

        return  result;
    }

    public User getUser(String username){

        SQLiteDatabase db = this.getReadableDatabase();
        String FETCH_USER = "SELECT * FROM " + Util.USER_TABLE_NAME +
                " WHERE " + Util.USERNAME + " = \"" + username + "\"";

        Log.e(String.valueOf(LOG), FETCH_USER);

        Cursor c = db.rawQuery(FETCH_USER, null);

        if (c.moveToFirst()){
            User user = new User();

            user.setPhone(c.getString(c.getColumnIndex(Util.PHONE)));
            user.setAddress(c.getString(c.getColumnIndex(Util.ADDRESS)));
            user.setPassword(c.getString(c.getColumnIndex(Util.PASSWORD)));
            user.setUsername(c.getString(c.getColumnIndex(Util.USERNAME)));
            user.setName(c.getString(c.getColumnIndex(Util.NAME)));


            return user;
        }
    }
    public boolean login(String username, String password){

        SQLiteDatabase db = getReadableDatabase();

        User user = getUser(username);

        if (user.getPassword().equals(password)){
            return true;
        }

        else{
            return false;
        }
    }

    public FoodItem getFoodItem(Integer foodID){

        SQLiteDatabase db = getWritableDatabase();

        String FETCH_FOOD_ITEM = "SELECT * FROM " + Util.FOOD_TABLE_NAME + " WHERE " + Util.FOOD_ID + " = \"" + foodID + "\"";

        Cursor c = db.rawQuery(FETCH_FOOD_ITEM, null);

        if(c!=null) c.moveToFirst();

        //Creating FoodItem object from cursor
        FoodItem foodItem = new FoodItem();
        foodItem.setFoodID(c.getInt(c.getColumnIndex(Util.FOOD_ID)));
        foodItem.setTitle(c.getString(c.getColumnIndex(Util.FOOD_TITLE)));
        foodItem.setDescription(c.getString(c.getColumnIndex(Util.FOOD_DESCRIPTION)));

        return foodItem;
    }

    public List<FoodItem> getAllFoodItems(){

        SQLiteDatabase db = getWritableDatabase();

        String FETCH_ALL_FOOD = "SELECT * FROM " + Util.FOOD_TABLE_NAME;

        Cursor c = db.rawQuery(FETCH_ALL_FOOD, null);

        final int dateIndex = c.getColumnIndex(Util.FOOD_DATE);
        final int timeIndex = c.getColumnIndex(Util.FOOD_PICKUP_TIME);
        final int quantityIndex = c.getColumnIndex(Util.FOOD_QUANTITY);
        final int locationIndex = c.getColumnIndex(Util.FOOD_LOCATION);
        final int imageIndex = c.getColumnIndex(Util.FOOD_IMAGE_RES);


        final int idIndex = c.getColumnIndex(Util.FOOD_ID);
        final int titleIndex = c.getColumnIndex(Util.FOOD_TITLE);
        final int descIndex = c.getColumnIndex(Util.FOOD_DESCRIPTION);


        try {
            if (!c.moveToFirst()) {
                return new ArrayList<>();
            }

            final List<FoodItem> foodItemList = new ArrayList<>();

            do {

                final String date = c.getString(dateIndex);
                final String quantity = c.getString(quantityIndex);
                final String time = c.getString(timeIndex);
                final String location = c.getString(locationIndex);

                byte[] bitmapData = c.getBlob(imageIndex);
                final Bitmap imageRes = BitmapFactory.decodeByteArray(bitmapData, 0, bitmapData.length);

                foodItemList.add(new FoodItem(title, description, date, time, location, quantity, imageRes));

            } while (c.moveToNext());

            return foodItemList;

        } finally {
            c.close();
            db.close();
        }
    }


}
import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CalendarView;
        import android.widget.TextView;
        import android.widget.Toast;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.fragment.app.FragmentActivity;

        import android.app.Activity;
        import android.content.Intent;
        import android.graphics.Bitmap;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.google.android.gms.maps.CameraUpdateFactory;
        import com.google.android.gms.maps.GoogleMap;
        import com.google.android.gms.maps.OnMapReadyCallback;
        import com.google.android.gms.maps.SupportMapFragment;
        import com.google.android.gms.maps.model.LatLng;
        import com.google.android.gms.maps.model.MarkerOptions;
        import com.paypal.android.sdk.payments.PayPalConfiguration;
        import com.paypal.android.sdk.payments.PayPalPayment;
        import com.paypal.android.sdk.payments.PayPalService;
        import com.paypal.android.sdk.payments.PaymentActivity;
        import com.paypal.android.sdk.payments.PaymentConfirmation;

        import org.json.JSONException;

        import java.math.BigDecimal;
        import java.util.ArrayList;

public class AddtCart extends FragmentActivity implements OnMapReadyCallback {

    private TextView dTitle,dDes, dDate, dQuantity;

    private Button AddtCart;
    private Bitmap bitmap;

    DatabaseHelper db;
    private ImageView dimageView;

    private static final float DEFAULT_ZOOM = 15f;
    public static final int PAYPAL_REQUEST_CODE = 7171;

    private static PayPalConfiguration config = new PayPalConfiguration()
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(com.example.foodapp.config.PAYPAL_CLIENT_ID);

    private Button paybutton;
    String amount = "1";

    ArrayList<LatLng> list;
    ArrayList<String> nameLs;
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addto_cart);Button);

        db = new DatabaseHelper2(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        Intent i =  getIntent();
        list = addpage.arrayList;
        nameLs = addpage.nameLs;

        paybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processPay();
            }
        });

    }
    public void storecart(View view){
        if(!dTitle.getText().toString().isEmpty() &&  mimageView.getDrawable()!= null  && dQuantity != null) {

            db.storeCart(new Item(mTitle.getText().toString(),dQuantity.getText().toString(),bitmap));

            Toast.makeText(Addtcart.this,"Success",Toast.LENGTH_SHORT).show();

            Intent i = new Intent(com.example.foodrescue.AddtCart.this, homepage.class);
            startActivity(i);
            finish();
        }
        else{
            Toast.makeText(com.example.foodrescue.AddtCart.this,"",Toast.LENGTH_SHORT).show;
        }
    }
    private void processPay() {

        PayPalPay payPalPay = new PayPal(new BigDecimal("100"),"AUD",

                "Free food",PayPal.PAYMENT_INTENT_SALE);

        Intent i = new Intent(this, PaymentActivity.class);

        i.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,config);
        i.putExtra(PaymentActivity.EXTRA_PAYMENT,payPalPayment);
        startActivityForResult(i,PAYPAL_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PAYPAL_REQUEST_CODE){
            if(resultCode == RESULT_OK){

                PaymentConf conf = data.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION);

                if(conf != null){
                    try{
                        String paymentDetails = conf.toJSONObject().toString(4);

                        startActivity(new Intent(this, Payment.class)
                                .putExtra("PaymentDetail",paymentDetails)
                                .putExtra("PaymentAmount",amount)
                        );
                    }
                    catch (JSONException e){
                        e.printStackTrace();
                    }
                }
                else if(resultCode == Activity.RESULT_CANCELED)
                    Toast.makeText(this,"Payment cancel", Toast.LENGTH_SHORT).show();
            }
            else if(resultCode == Payment.RESULT_EXTRAS_INVALID){
                Toast.makeText(this,"Invalid", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        for(int i = 0; i < list.size(); i ++){
            mMap.addMarker(new MarkerOptions().position(list.get(i)).title(nameLs.get(i)));
            moveCamera(list.get(i),DEFAULT_ZOOM);

        }
    }
    private void moveCamera(LatLng latLng, float zoom){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,zoom));
    }
}

public class CalendarActivity extends AppCompatActivity {

    CalendarView cal;
    TextView dateText;  String date;

    @Override

    public void initializeCalendar() {
        cal = findViewById(R.id.calendarView);
        cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                Toast.makeText(CalendarActivity.this, dayOfMonth + "/" + month+1 + "/" + year, Toast.LENGTH_SHORT).show();
                date = String.valueOf(dayOfMonth) + "/" + String.valueOf(month+1) + "/" + String.valueOf(year);

                dateTextView.setText(date);
            }
        });
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        dateText = findViewById(R.id.dateDisplayTextView);

        selectDateButton = findViewById(R.id.selectDateButton);
        initializeCalendar();

        selectDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("date", date);
                setResult(1, resultIntent);
                finish();
            }
        });
    }


}
    public FoodI(){

    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getDesc {

        return desc;
        }

public void setDesc(String descr) {

        this.desc = descr;
        }

public String getPickup() {

        return pickup;
        }



public String getPickupT {

        return pickupT;
        }


public String getLocation() {
        return location; }

public void setLocation(String location) {

        this.location = location;
        }

public String getQuant() {

        return quant;
        }

public byte[] getImageRes() {

        return Util.getBitmapAsByteArray(imageRes);
        }

public Integer getFoodID() {

        return foodID;
        }

public void setFoodID(Integer foodID) {

        this.foodID = foodID;
        }

//Returns all details excluding Title in String
public String getDetails(){
        String details = this.getDesc() + ", " + this.getQuantity() + ", " + this.getPickupDate() + ", "
        + this.getPickupTime() + ", " + this.getLocation();

        return details;
        }
        }
        import androidx.annotation.Nullable;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.appcompat.widget.Toolbar;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import android.content.Intent;
        import android.database.sqlite.SQLiteDatabase;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.os.Bundle;
        import android.preference.PreferenceManager;
        import android.provider.ContactsContract;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.Toast;

        import com.example.foodrescue.DatabaseHelper;
        import com.example.foodrescue.FoodItem;
        import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class HomeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseHelper db; FloatingActionButton addFoodItemButton; String username;

    public void setRecyclerView(){
        recyclerViewAdapter = new RecyclerViewAdapter(db.getAllFoodItems(), this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recyclerViewAdapter);
    }
    @Override
    protected void onActivityResult(int requestC, int resultC, @Nullable Intent data) {
        super.onActivityResult(requestC, resultC, data);

        if(requestCode==2){

            if(data.getBooleanExtra("INSERT_OK", false)){
                Toast.makeText(this, "Food Item was successfully added!", Toast.LENGTH_SHORT).show();
                setRecyclerView();
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        addFoodItemButton = findViewById(R.id.fab);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.home_toolbar);
        setSupportActionBar(myToolbar);
        Intent intent = getIntent();
        username = intent.getStringExtra("user");

        db = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        setRecyclerView();
        addFoodItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addFoodInent = new Intent(HomeActivity.this, AddFoodActivity.class);
                addFoodInent.putExtra("user", username);

                startActivityForResult(addFoodInent, 2);
            }
        });
    }

import Bitmap;

    public class Collection {

        private final String title;
        private final String quant;
        private final Bitmap img;

        public String getQuantity() {

            return quant;
        }

        public String getTitle() {

            return title;
        }

        public Bitmap getImage() {

            return img;
        }s

        public Item(String title, String quant, Bitmap img) {

            this.title = title;this.quant = quant;this.img = img;
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }


    //Managing selection in Action Overflow of the Toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.toolbar_opt1: {
                //TODO WHEN OPTION 1 IS SELECTED
                break;
            }
            case R.id.toolbar_opt2: {
                //TODO WHEN OPTION 2 IS SELECTED
                break;
            }

            case R.id.toolbar_opt3: {
                Intent listIntent = new Intent(HomeActivity.this, ListActivity.class);
                listIntent.putExtra("username", username);
                startActivity(listIntent);

                break;
            }
        }
        return true;
    }


}

public class Payment extends AppCompatActivity {

    private TextV textID,textAmount,textStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        textID = findViewById(R.id.txtID);
        textAmount = findViewById(R.id.txtAmount);
        textStatus = findViewById(R.id.txtStatus);
        Intent intent = getIntent();
        try{
            JSONObject jsonObject = new JSONObject(intent.getStringExtra("Payment"));
            showDetails(jsonObject.getJSONObject("response"), intent.getStringExtra("PaymentAm"));
        }catch (JSONException e){ e.printStackTrace();
        }
    }

}
import androidx.appcompat.app.AppCompatActivity;
        import androidx.appcompat.widget.Toolbar;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import android.content.Intent;
        import android.os.Bundle;

        import com.example.foodrescue.DatabaseHelper;

public class ListActivity extends AppCompatActivity {

    String username; DatabaseHelper db; RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        .onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        ;
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.myListRecyclerView);

        setRecyclerView();
    }

}

public class MainActivity extends AppCompatActivity {

    EditText usernameEditText, passwordEditText;Button loginButton, signupButton;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        loginButton = findViewById(R.id.loginButton);
        signupButton = findViewById(R.id.signupButton);

        db = new DatabaseHelper(this);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean loginResult = db.login(usernameEditText.getText().toString(), passwordEditText.getText().toString());

                if (loginResult){
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                    Intent intent  = new Intent(MainActivity.this, HomeActivity.class);
                }

                else{
                    Toast.makeText(MainActivity.this, "Error! Incorrect Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if(requestCode==2){

                String returnedUsername = data.getStringExtra("username");

                usernameEditText.setText(returnedUsername);

                passwordEditText.setText("");
            }
        }

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent signupIntent = new Intent(MainActivity.this, SignupActivity.class);

                if(usernameEditText.getText().toString()!=null){

                    signupIntent.putExtra("username", usernameEditText.getText().toString());
                }
                startActivityForResult(signupIntent, 2);
            }
        });
    }

    public class Util {


        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "user_db";
        public static final String USER_TABLE_NAME = "users";
        public static final String FOOD_TABLE_NAME = "food";
        public static final String USER_FOOD_TABLE_NAME = "users_food";
        public static final String FOOD_ID = "food_id";
        public static final String FOOD_TITLE = "food_title";
        public static final String FOOD_DESCR = "food_descr";

        public static final String PHONE = "phone";
        public static final String ADDRESS = "address";
        public static final String NAME = "name";


        public static final String FOOD_DATE = "food_pickup_date";
        public static final String FOOD_PICKUP = "food_pickup";
        public static final String FOOD_QUANT = "food_quant";
        public static final String FOOD_LOCATION = "food_location";
        public static final String  FOOD_IMAGE = "food_image";
        public static final String USERNAME = "username";
        public static final String PASSWORD = "password";

        public static final String CREATE_USER_TABLE = "CREATE TABLE " + USER_TABLE_NAME + "("
                + USERNAME + " TEXT PRIMARY KEY," + NAME + " TEXT," + PASSWORD + " TEXT,"
                + PHONE + " TEXT," + ADDRESS + " TEXT)";

        public static final String CREATE_FOOD_TABLE = "CREATE TABLE " + FOOD_TABLE_NAME + "("
                + FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + " TEXT," + FOOD_IMAGE + " TEXT," + FOOD_DATE + " TEXT,"
                + FOOD_PICKUP + " TEXT," + FOOD_QUAN + " TEXT," + FOOD_LOCATION + " TEXT," + USERNAME + " TEXTFOOD_TITLE + " TEXT," + FOOD_DESC " )";

        public static byte[] getBitmapAsByteArray(Bitmap bitmap) {

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG,
                    0, outputStream);
            return outputStream.toByteArray();
        }
    }
}

public class DatabaseHelper2 extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "mdb.db";
    private static final String createTablequery = "create table cdetail (carttitle TEXT" +",cquan TEXT" +",cimage BLOB)";
    private ByteArrayOutputStream byteArrayOutputStream;
    private byte[] imageByte;
    public DatabaseHelper2(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    public void sCart(Item object){

        SQLiteDatabase db = this.getWritableDatabase();

        Bitmap imageToBitmap = object.Image();
        byteArrayOutputStream = new ByteArrayOutputStream();
        imageToBitmap.compress(Bitmap.CompressFormat.PNG,100,byteArrayOutputStream);

        imageByte = byteArrayOutputStream.toByteArray();
        ContentValues contentValues = new ContentValues();
        contentValues.put("cartimage",imageByte);
        contentValues.put("carttitle",object.getTitle());
        contentValues.put("cartquan", object.getQuantity());

        long result = db.insert("cartdetail",null,contentValues);

        if(result != -1) db.close();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(createTablequery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public ArrayList<Item> getAllData(){

        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<Item> modelList = new ArrayList<>();

        Cursor cursor = db.rawQuery("select * from cartdetail", null);
        if(cursor.getCount() != 0)
        {
            while(cursor.moveToNext()){
                String TITLE = cursor.getString(0);
                String Quantity = cursor.getString(1);
            }
            return modelList;
        }
        else return modelList;
    }
}
